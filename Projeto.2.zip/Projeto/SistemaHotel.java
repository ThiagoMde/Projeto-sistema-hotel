import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;

import javax.swing.JOptionPane;

public class SistemaHotel {
     private static List<Quarto> quartos = new ArrayList<>();
    private static List<Hospede> hospedes = new ArrayList<>();
    private static List<Reserva> reservas = new ArrayList<>();
    private static List<Funcionario> funcionarios = new ArrayList<>();

    public static void main(String[] args) {
        while (true) {
            String[] options = {"Gerenciar Quartos", "Gerenciar Hóspedes", "Gerenciar Reservas", "Gerenciar Funcionários", "Check-In", "Check-Out", "Sair"};
            int escolha = JOptionPane.showOptionDialog(null, "Escolha uma opção", "Sistema de Gerenciamento de Hotel",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            switch (escolha) {
                case 0:
                    gerenciarQuartos();
                    break;
                case 1:
                    gerenciarHospedes();
                    break;
                case 2:
                    gerenciarReservas();
                    break;
                case 3:
                    gerenciarFuncionarios();
                    break;
                case 4:
                    realizarCheckIn();
                    break;
                case 5:
                    realizarCheckOut();
                    break;
                case 6:
                    System.exit(0);
            }
        }
    }

    private static void gerenciarQuartos() {
        String[] options = {"Cadastrar Quarto", "Visualizar Quartos", "Atualizar Status", "Voltar"};
        int escolha = JOptionPane.showOptionDialog(null, "Gerenciamento de Quartos", "Sistema de Gerenciamento de Hotel",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

        switch (escolha) {
            case 0:
                cadastrarQuarto();
                break;
            case 1:
                visualizarQuartos();
                break;
            case 2:
                atualizarStatusQuarto();
                break;
            case 3:
                break;
        }
    }

    private static void cadastrarQuarto() {
        int numero = Integer.parseInt(JOptionPane.showInputDialog("Número do Quarto:"));
        String tipo = JOptionPane.showInputDialog("Tipo (Solteiro, Casal, Suíte):");
        int capacidade = Integer.parseInt(JOptionPane.showInputDialog("Capacidade:"));
        double preco = Double.parseDouble(JOptionPane.showInputDialog("Preço:"));
        quartos.add(new Quarto(numero, tipo, capacidade, preco));
        JOptionPane.showMessageDialog(null, "Novo quarto cadastrado com sucesso!");
    }

    private static void visualizarQuartos() {
        StringBuilder sb = new StringBuilder();
        for (Quarto q : quartos) {
            sb.append(q.toString()).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    private static void atualizarStatusQuarto() {
        int numero = Integer.parseInt(JOptionPane.showInputDialog("Número do Quarto:"));
        for (Quarto q : quartos) {
            if (q.getNumero() == numero) {
                String status = JOptionPane.showInputDialog("Novo Status (Disponível, Ocupado, Em Manutenção):");
                q.setStatus(status);
                JOptionPane.showMessageDialog(null, "Status do quarto atualizado com sucesso!");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Quarto não encontrado.");
    }

    private static void gerenciarHospedes() {
        String[] options = {"Cadastrar Hóspede", "Visualizar Hóspedes", "Voltar"};
        int escolha = JOptionPane.showOptionDialog(null, "Gerenciamento de Hóspedes", "Sistema de Gerenciamento de Hotel",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

        switch (escolha) {
            case 0:
                cadastrarHospede();
                break;
            case 1:
                visualizarHospedes();
                break;
            case 2:
                break;
        }
    }

    private static void cadastrarHospede() {
        String nome = JOptionPane.showInputDialog("Nome:");
        String cpf = JOptionPane.showInputDialog("CPF:");
        String dataNascimento = JOptionPane.showInputDialog("Data de Nascimento:");
        String endereco = JOptionPane.showInputDialog("Endereço:");
        String contato = JOptionPane.showInputDialog("Contato:");
        hospedes.add(new Hospede(nome, cpf, dataNascimento, endereco, contato));
        JOptionPane.showMessageDialog(null, "Novo hóspede cadastrado com sucesso!");
    }

    private static void visualizarHospedes() {
        StringBuilder sb = new StringBuilder();
        for (Hospede h : hospedes) {
            sb.append(h.toString()).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    private static void gerenciarReservas() {
        String[] options = {"Criar Reserva", "Visualizar Reservas", "Cancelar Reserva", "Voltar"};
        int escolha = JOptionPane.showOptionDialog(null, "Gerenciamento de Reservas", "Sistema de Gerenciamento de Hotel",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

        switch (escolha) {
            case 0:
                criarReserva();
                break;
            case 1:
                visualizarReservas();
                break;
            case 2:
                cancelarReserva();
                break;
            case 3:
                break;
        }
    }

    private static void criarReserva() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        sdf.setLenient(false);  // Para garantir que a data deve ser estritamente válida
    
        String cpfHospede = JOptionPane.showInputDialog("CPF do Hóspede:");
        Hospede hospede = null;
        for (Hospede h : hospedes) {
            if (h.getCpf().equals(cpfHospede)) {
                hospede = h;
                break;
            }
        }
        if (hospede == null) {
            JOptionPane.showMessageDialog(null, "Hóspede não encontrado.");
            return;
        }
    
        int numeroQuarto = Integer.parseInt(JOptionPane.showInputDialog("Número do Quarto:"));
        Quarto quarto = null;
        for (Quarto q : quartos) {
            if (q.getNumero() == numeroQuarto && q.getStatus().equals("Disponível")) {
                quarto = q;
                break;
            }
        }
        if (quarto == null) {
            JOptionPane.showMessageDialog(null, "Quarto não encontrado ou indisponível.");
            return;
        }
    
        try {
            String dataEntradaStr = JOptionPane.showInputDialog("Data de Entrada (dd/MM/yyyy):");
            Date dataEntrada = sdf.parse(dataEntradaStr);
            
            String dataSaidaStr = JOptionPane.showInputDialog("Data de Saída (dd/MM/yyyy):");
            Date dataSaida = sdf.parse(dataSaidaStr);
    
            if (dataSaida.before(dataEntrada)) {
                JOptionPane.showMessageDialog(null, "Data de saída deve ser posterior à data de entrada.");
                return;
            }
    
            reservas.add(new Reserva(hospede, quarto, sdf.format(dataEntrada), sdf.format(dataSaida)));
            JOptionPane.showMessageDialog(null, "Reserva criada com sucesso!");
    
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(null, "Data inválida. Por favor, insira no formato dd/MM/yyyy.");
        }
    }
    

    private static void visualizarReservas() {
        StringBuilder sb = new StringBuilder();
        for (Reserva r : reservas) {
            sb.append(r.toString()).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    private static void cancelarReserva() {
        int numeroQuarto = Integer.parseInt(JOptionPane.showInputDialog("Número do Quarto da Reserva a ser cancelada:"));
        for (Reserva r : reservas) {
            if (r.getQuarto().getNumero() == numeroQuarto) {
                r.getQuarto().setStatus("Disponível");
                reservas.remove(r);
                JOptionPane.showMessageDialog(null, "Reserva cancelada com sucesso!");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Reserva não encontrada.");
    }

    private static void gerenciarFuncionarios() {
        String[] options = {"Cadastrar Funcionário", "Visualizar Funcionários", "Voltar"};
        int escolha = JOptionPane.showOptionDialog(null, "Gerenciamento de Funcionários", "Sistema de Gerenciamento de Hotel",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

        switch (escolha) {
            case 0:
                cadastrarFuncionario();
                break;
            case 1:
                visualizarFuncionarios();
                break;
            case 2:
                break;
        }
    }

    private static void cadastrarFuncionario() {
        String nome = JOptionPane.showInputDialog("Nome:");
        String cpf = JOptionPane.showInputDialog("CPF:");
        String cargo = JOptionPane.showInputDialog("Cargo:");
        double salario = Double.parseDouble(JOptionPane.showInputDialog("Salário:"));
        String turno = JOptionPane.showInputDialog("Turno:");
        funcionarios.add(new Funcionario(nome, cpf, cargo, salario, turno));
        JOptionPane.showMessageDialog(null, "Novo funcionário cadastrado com sucesso!");
    }

    private static void visualizarFuncionarios() {
        StringBuilder sb = new StringBuilder();
        for (Funcionario f : funcionarios) {
            sb.append(f.toString()).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    private static void realizarCheckIn() {
        String cpfHospede = JOptionPane.showInputDialog("CPF do Hóspede:");
        for (Reserva r : reservas) {
            if (r.getQuarto().getStatus().equals("Ocupado") && r.toString().contains(cpfHospede)) {
                JOptionPane.showMessageDialog(null, "Check-in realizado com sucesso!");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Reserva não encontrada ou hóspede já fez check-in.");
    }

    private static void realizarCheckOut() {
        int numeroQuarto = Integer.parseInt(JOptionPane.showInputDialog("Número do Quarto para Check-Out:"));
        for (Reserva r : reservas) {
            if (r.getQuarto().getNumero() == numeroQuarto) {
                r.getQuarto().setStatus("Disponível");
                reservas.remove(r);
                JOptionPane.showMessageDialog(null, "Check-out realizado com sucesso!");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Reserva não encontrada.");
    }
}
